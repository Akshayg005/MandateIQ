# SETUP GUIDE — Windows native, from zero to Day 1

No WSL. Docker Desktop assumed installed. Every command below is PowerShell.

Labels:
- 🧍 **YOU** — only you can do this (accounts, keys, clicks, judgement)
- 🤖 **CLAUDE** — Claude Code does it; you approve
- ⚙️ **SCRIPT** — one command, no thinking required

---

# STAGE A — Prerequisites (🧍 YOU, ~15 min)

Open **PowerShell** (not cmd) and check each:

```powershell
python --version       # 3.11, 3.12 or 3.13 all work
node --version         # 20.x or later
docker --version
git --version
claude --version       # must print something -- silence means not installed
```

Run them one at a time, not as a block. PowerShell will happily run four of
five and you may not notice which one printed nothing.

Missing anything:

| Tool | Get it |
|---|---|
| Python | 3.11, 3.12 or 3.13 all work. python.org → installer → **tick "Add python.exe to PATH"** |
| Node 20+ | nodejs.org LTS installer |
| Claude Code | `npm install -g @anthropic-ai/claude-code` |

**Start Docker Desktop** from the Start menu and wait for the tray whale to
stop animating. Then `docker info` must show a **Server:** section — if it
errors with `npipe:////./pipe/dockerDesktopLinuxEngine`, the app isn't up yet.

**Allow local scripts to run.** Windows blocks `.ps1` files by default:

```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

If you'd rather not change it permanently, use this in each new terminal
instead:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

---

# STAGE B — Razorpay account (🧍 YOU, ~20 min)

**Do this first, tonight.** It is the only step with a human approval delay.

1. Sign up at `razorpay.com`, then toggle to **Test Mode** at the top of the
   dashboard. Confirm it says Test Mode before anything else.
2. **Settings → API Keys → Generate Test Key.** Copy both. The secret shows
   **once**. Key ID must start `rzp_test_`.
3. **Check the left nav for Subscriptions.** If it is missing or greyed out,
   **request activation via support right now** — it needs human approval and
   you need it working by Day 2.
4. **Do not create the webhook yet.** The URL field is required and you have
   no tunnel until Day 2.

---

# STAGE C — Drop in the scaffold (🧍 YOU, 2 min)

```powershell
mkdir mandate-recovery
cd mandate-recovery
Expand-Archive -Path "$HOME\Downloads\mandate-recovery-scaffold.zip" -DestinationPath .
```

The zip contains a `scaffold\` folder. Flatten it:

```powershell
Get-ChildItem -Path scaffold -Force | Move-Item -Destination . -Force
Remove-Item scaffold -Recurse -Force
Get-ChildItem -Force
```

`-Force` on `Get-ChildItem` is what includes hidden items like `.claude`.
Without it that folder is left behind and no hooks ever fire.

You must see `CLAUDE.md`, `.claude`, `scripts`, `run.ps1`, `setup.ps1` at the
**top level**. If `.claude` is missing, the second Move-Item didn't run —
that's the one that catches hidden folders.

```powershell
git init
```

---

# STAGE D — Bootstrap (⚙️ SCRIPT, ~5 min)

```powershell
.\setup.ps1
```

Creates the venv, installs dependencies, starts Postgres in Docker,
scaffolds both Vite workspaces, copies `.env.example` → `.env`, and
**self-tests the guards**.

**Watch for this line:**

```
    guards OK
```

If you see `GUARD DID NOT FIRE`, stop. Don't build on a repo where the
invariants aren't enforced — by Day 8 an LLM import will have been sitting in
the decision core for a week and you won't know when it arrived.

**Port 5432 already in use?**

```powershell
docker ps --filter "publish=5432"
docker stop <that-container>
```

---

# STAGE E — Keys (🧍 YOU, ~10 min)

**E1. Generate a webhook secret:**

```powershell
$b = New-Object byte[] 32
[System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b)
($b | ForEach-Object { $_.ToString("x2") }) -join ""
```

Save that string — you'll paste it into Razorpay on Day 2.

**E2. Fill `.env`:**

```powershell
notepad .env
```

```
RAZORPAY_KEY_ID=rzp_test_...
RAZORPAY_KEY_SECRET=...
RAZORPAY_WEBHOOK_SECRET=<the string from E1>
ANTHROPIC_API_KEY=sk-ant-...
```

The webhook secret is a **different value** from the API secret. Mixing them
up produces signature failures that look like code bugs, and you'll hunt in
the wrong place for an hour.

**E3. Wire the Razorpay MCP server:**

```powershell
$kid  = "rzp_test_xxxxx"
$sec  = "xxxxx"
$auth = "Basic " + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("${kid}:${sec}"))

$cfg = @{
  command = "npx"
  args    = @("mcp-remote","https://mcp.razorpay.com/mcp","--header","Authorization:$auth")
} | ConvertTo-Json -Compress

claude mcp add-json razorpay $cfg
claude mcp list
```

Expect `razorpay` in the output. If `add-json` is rejected, run
`claude mcp --help` — this CLI surface changes faster than anything else here.

Docker alternative:

```powershell
claude mcp add razorpay -- docker run --rm -i -e RAZORPAY_KEY_ID=$kid -e RAZORPAY_KEY_SECRET=$sec razorpay/mcp
```

**E4. Parallel worktree for the landing page:**

```powershell
git worktree add ..\mr-site site
```

---

# STAGE F — Verify (⚙️ SCRIPT, 1 min)

```powershell
.\run.ps1 verify
```

Runs five checks: guards fire, frozen guard denies, no live keys, Postgres
reachable, and **a real test-mode order created through your API keys**.

That last one printing `order_...` is what actually proves you're ready.

```powershell
git add -A
git commit -m "scaffold"
```

Commit before Claude touches anything, so you can diff what it changed.

---

# STAGE G — The Opus planning session (🧍 + 🤖, ~45 min)

```powershell
claude --model opus
```

**G1.** Press `shift+tab` **twice**. Confirm the plan-mode indicator appears.

**G2. Check the hook fired.** You should see the
`════ MANDATE RECOVERY ENGINE ════` banner. **No banner means the hooks
aren't running** — you're probably not in the repo root. Fix it before
continuing; without hooks you have no invariants.

**G3.** Copy everything inside the fences in `OPUS_PROMPT.md`, paste, send.

**G4.** It writes `PLAN_DETAIL.md`. **Read it — don't skim.** Three checks:

- Does the person-period schema show a worked example for a **censored**
  mandate (one that burned all four slots without resolving)? If it only
  shows the recovered case, censoring isn't understood — that's a Day 3 bug
  that inflates every number in your final report.
- Does the idempotency key contain a timestamp, UUID or PID? If yes it's
  broken; the key must be stable across restarts.
- Is there a dependency graph showing which day-slips cascade?

**G5.** Then send the adversarial follow-up:

```
Before we start building: run the payments-domain subagent against your own
PLAN_DETAIL.md. Report what it says without defending yourself. Then tell me
which of its objections you think are correct, and which you would push back
on and why.
```

Highest-value fifteen minutes in the project. A flaw found now costs an hour.

```powershell
git add -A
git commit -m "PLAN_DETAIL from planning session"
```

---

# STAGE H — Day 1 (🧍 + 🤖)

**H1.** `/orient` — check its six drift-check answers before approving anything.

**H2.** Approve the plan. Claude builds the ledger schema and repo skeleton.

**H3. 🧍 YOU write the freeze yourself.** Not delegated — pre-registration
only means something if a person committed to it before knowing which numbers
would flatter them. The PreToolUse hook blocks Claude from `eval/frozen/`
anyway, by design.

Write `eval\frozen\sim_config.yaml` and `eval\frozen\protocol.md` in your own
editor, then:

```powershell
.\run.ps1 freeze
Get-Content reports\FREEZE_HASH
```

**H4.** Claude implements `eval\baseline_ladder.py` and produces the first
baseline number.

**H5.** Close:

```
/checkpoint
```

```powershell
.\run.ps1 checkpoint -Day 1
```

Then fill the four handoff fields in `STATE.md` by hand.

**Day 1 gate:** baseline produces a number · guards fire on a deliberate
violation · `FREEZE_HASH` recorded · `STATE.md` has a real handoff.

---

# DAY 2 — The webhook tunnel

Skip ngrok. It requires an account token for every tunnel and its Scoop
package is in a broken half-state on your machine. Cloudflare needs no
account.

```powershell
Invoke-WebRequest -Uri "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe" -OutFile "$HOME\cloudflared.exe"
& "$HOME\cloudflared.exe" tunnel --url http://localhost:8000
```

It prints `https://random-words.trycloudflare.com`. Leave that terminal open.

Then in the Razorpay dashboard → **Settings → Webhooks → Create New Webhook**:

| Field | Value |
|---|---|
| Webhook URL | `https://<random>.trycloudflare.com/webhook/razorpay` |
| Secret | the string from Stage E1 |
| Alert Email | leave as-is |
| Active Events | `payment.failed`, `payment.captured`, `payment.authorized`, `subscription.charged`, `subscription.pending`, `subscription.halted`, `subscription.cancelled`, `subscription.paused`, `subscription.resumed` |

Skip the dispute events — different track.

> ⚠️ The tunnel URL **changes every restart**, and it dies when you close the
> terminal. Re-paste it into the Razorpay dashboard each time. When webhooks
> mysteriously stop arriving on Day 6, this is why — and you'll check your own
> code first.

---

# THE DAILY LOOP (Days 2–12)

| | Move | Who |
|---|---|---|
| **1** | `/clear`, fresh session, then `/orient` | 🧍 → 🤖 |
| **2** | **Check its six drift-check answers.** If any are wrong, stop — it hasn't oriented, and everything after compounds the error | 🧍 |
| **3** | Read the day's plan. Approve or push back. **Never approve a plan you didn't read** | 🧍 |
| **4** | Build. Something breaks → `/log-incident` **before** fixing | 🤖 |
| **5** | `/checkpoint`, then `.\run.ps1 checkpoint -Day N`, tick gates honestly, commit | 🧍 + 🤖 |

Step 2 pays for itself: ten seconds of reading catches a drifted session
before it writes any code.

**Model routing:**

```powershell
claude --model opus      # Days 3, 4, 5 — model, conformal, allocator
claude --model sonnet    # everything else
```

- `/clear` between days. **Never `/compact` mid-task** — compaction silently
  drops your invariants.
- Never `--dangerously-skip-permissions` on the money path.

---

# COMMAND TRANSLATION

`PLAN.md` was written with `make`. On Windows:

| PLAN.md says | You run |
|---|---|
| `make test` | `.\run.ps1 test` |
| `make ci` | `.\run.ps1 ci` |
| `make eval` | `.\run.ps1 eval` |
| `make eval-quick` | `.\run.ps1 eval-quick` |
| `make bench` | `.\run.ps1 bench` |
| `make chaos KILLS=50` | `.\run.ps1 chaos -Kills 50` |
| `make freeze` | `.\run.ps1 freeze` |
| `make checkpoint DAY=3` | `.\run.ps1 checkpoint -Day 3` |
| `make report` | `.\run.ps1 report` |
| `./setup.sh` | `.\setup.ps1` |

`.\run.ps1 help` lists everything.

---

# TROUBLESHOOTING

| Symptom | Cause | Fix |
|---|---|---|
| `.ps1 cannot be loaded` | Execution policy | `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` |
| No banner at session start | Hooks not running | You're not in the repo root, or `.claude\` didn't extract |
| Guard seems to pass everything | It couldn't resolve input | Run `python scripts\guard_invariants.py --all`. If it warns "no files resolved", the hook wiring is wrong |
| `python` not found in hook | PATH issue | Use the full venv path in `.claude\settings.json`, or reinstall Python with "Add to PATH" |
| Webhooks stopped arriving | Tunnel restarted, URL changed | Update the URL in the Razorpay dashboard |
| Signature verification fails | Using API secret, not webhook secret | Different values. Check `RAZORPAY_WEBHOOK_SECRET` |
| No Subscriptions in dashboard | Not enabled on the test account | Support request. Do this on Day 0 |
| Postgres won't start | Port 5432 taken | `docker ps --filter "publish=5432"`, stop it |
| `npm create vite` hangs | Waiting on a prompt | Run `.\setup.ps1 -SkipFrontend`, do the frontend later |
| New session proposes off-plan work | It didn't orient | Stop it. `/orient`. Check its six answers |

---

# THE ONE-PAGE VERSION

```
TONIGHT   A prerequisites + execution policy
          B Razorpay account -- CHECK SUBSCRIPTIONS IS ENABLED
DAY 0     C unzip + flatten -> D .\setup.ps1 -> E keys + MCP
          F .\run.ps1 verify -> git commit
DAY 0 pm  G Opus planning -> read PLAN_DETAIL.md -> argue with it
DAY 1     Skeleton + ledger (Claude) -> freeze written BY YOU
          -> .\run.ps1 freeze -> /checkpoint
DAY 2     cloudflared tunnel -> create the Razorpay webhook
DAY 2-12  /clear -> /orient -> check answers -> approve -> build
          -> /log-incident when things break -> /checkpoint -> commit
```

Three things you personally must not delegate: **writing the freeze**,
**reading the plan before approving it**, and **checking the six drift-check
answers each session.** Everything else Claude can carry.
