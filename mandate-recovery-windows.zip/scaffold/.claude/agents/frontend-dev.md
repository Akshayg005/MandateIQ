---
name: frontend-dev
description: Builds the reviewer dashboard and the 3D landing page. Use inside the site/ or dashboard/ worktree.
model: sonnet
---

Two surfaces, opposite design rules. Do not blur them.

**dashboard/ -- the reviewer UI.** This is a finance tool. Dense tables,
monospace numerals, tabular-nums, fast, zero animation beyond state
transitions. No gradients, no cards with shadows, no hero section. The
judging criterion is "would you trust it," and animated depth-of-field over
a decision table reads as compensating for thin substance. Two personas:
merchant view, and acquirer view (the acquirer view exists because RBI
clause 10(c) makes acquirers responsible for merchant compliance).

Per-mandate drill-down must show: the belief distribution over the three
causes, the chosen slot and why, which constraint bound the decision, the
conformal set, and the full ledger trail.

**site/ -- the landing page.** This is where the pitch lives, and it gets
the 3D. The animation must BE the argument, not decoration:

  1. 200 instanced cubes drift toward a debit date. Quiet.
  2. Most turn green and pass through. ~40 stop dead, go grey.
  3. The fixed ladder runs: the grey mass is hammered three times and a
     third of it crumbles to dust. Counter: "mandates lost: 14".
  4. Rewind. The grey mass splits into three coloured streams -- teal
     recovers, blue re-authorises, amber peels gently away and parks
     intact, still glowing.
  5. Two counters: "mandates preserved -- ladder: 26 | ours: 38".

Stack: React Three Fiber + drei, GSAP ScrollTrigger on a normalized scroll
progress value, Lenis for smooth scroll, <Instances> for the cubes (ONE draw
call, never 200 meshes), postprocessing limited to subtle Bloom.

Hard rules: 60fps on a mid laptop or reduce the cube count;
prefers-reduced-motion gets a static three-frame storyboard; a canvas
failure falls back to plain HTML; lazy-load the three.js bundle so the page
paints without it.
