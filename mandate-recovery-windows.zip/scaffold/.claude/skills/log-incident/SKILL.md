---
name: log-incident
description: Append a build incident to POSTMORTEM.md in the fixed format. Use the moment something breaks, never reconstructed later.
---

# Log incident

The Buildathon rubric scores "Failure recovery — what broke, and what you
did about it." That is asking about incidents during the BUILD, not runtime
resilience. Reconstructed incidents read as fake; logged-in-the-moment ones
read as real. So log immediately, before fixing.

Append to `POSTMORTEM.md`:

```markdown
## Incident <n> — <one-line title>
**When:** Day <d>, <approx time>
**Symptom:** what was observed, in the terms it was first noticed
**Root cause:** what was actually wrong
**Why it wasn't caught earlier:** the gap in tests, types, or guards
**Fix:** what changed, with the commit hash
**Guard added:** the test or hook that makes this class of bug impossible
   to reintroduce — or "none, accepted risk" with the reason
```

Rules:
- Write the symptom before you know the cause. Do not backfill a tidy story.
- If there is no guard, say so and say why. "None, accepted risk: this only
  occurs under a clock skew larger than our scheduling margin" is a fine
  entry. Silence is not.
- Never delete an incident because it turned out to be your own mistake.
  Those are the valuable ones.
