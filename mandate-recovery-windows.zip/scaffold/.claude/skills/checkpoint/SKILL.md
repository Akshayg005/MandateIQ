---
name: checkpoint
description: End-of-session ritual. Regenerate STATE.md, tick gates honestly, and write the handoff so the next session starts oriented rather than blind.
---

# Checkpoint

Run this before ending any session, and before any `/clear`. A session that
ends without a checkpoint costs the next session twenty minutes and risks a
half-finished change nobody remembers making.

## Step 1 — verify, then run

```
/verify-invariants
.\run.ps1 checkpoint -Day <n>
```

`scripts/checkpoint.py` regenerates the auto block of `STATE.md` from git,
gates, tests and results, and appends a line to `SESSIONS.md`. It cannot
infer the human half — that is step 3.

## Step 2 — tick gates honestly

Update `reports/gates.md`. Tick a gate ONLY when its condition is actually
verified, not when the code exists. An honest open gate is worth more than a
false green: the false green is discovered on day eleven, when it is
expensive.

## Step 3 — write the handoff in STATE.md

Fill these four by hand. Be specific enough that a session with zero memory
could resume without re-deriving anything:

- **Where I stopped, exactly** — file and function, and what state it is in.
  "Mid-way through `allocator.py::backward_induct`; belief update written,
  terminal-value case is a stub returning 0."
- **The single next action** — one concrete step, not a topic.
  "Implement the terminal-value case at `allocator.py:88`, then `.\run.ps1 eval-quick`."
- **Half-finished work** — stubs, deliberately-red tests, uncommitted
  experiments, branches. Anything a fresh session would otherwise rediscover
  the hard way.
- **What I am least confident about** — the thing most likely to be wrong.
  Naming it costs nothing and has the highest expected value of anything in
  this file.

## Step 4 — move decisions out

Anything under "Decisions made but not yet written into DECISIONS.md" goes
into `DECISIONS.md` now, then gets deleted from `STATE.md`. `STATE.md` is a
snapshot, not an archive — it is read every session, so every stale line is
a recurring tax.

## Step 5 — keep it short

If `checkpoint.py` warns that `STATE.md` is over 145 lines, trim it. Move
narrative into `SESSIONS.md`. Do not let the file that exists to fight
context bloat become context bloat.

## Step 6 — commit

```
git add -A && git commit -m "checkpoint: day <n> — <one line>"
```
