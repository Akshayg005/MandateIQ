---
name: verify-invariants
description: Run the full invariant guard suite plus tests and report a clean pass/fail summary. Use before any commit, and at the end of every build day.
---

# Verify invariants

Run these in order and report a compact summary. Stop at the first hard failure.

1. `python scripts\guard_invariants.py --all`
2. `python scripts\guard_frozen.py` (verify it denies eval\frozen\)
3. `.\run.ps1 lint`
4. `.\run.ps1 test`
5. `.\run.ps1 eval-quick`
6. `git diff --stat reports\FREEZE_HASH` — must be empty

Report as:

```
INVARIANTS
  1 no LLM in core        PASS / FAIL <detail>
  2 integer paise         PASS / FAIL <detail>
  3 ledger-before-action  PASS / FAIL <detail>
  4 frozen eval intact    PASS / FAIL <detail>
  5 test mode only        PASS / FAIL <detail>
  6 no hard cancel        PASS / FAIL <detail>
TESTS      <n passed, n failed>
QUICK EVAL recovered% / attempts / preserved
```

If anything fails, give the file, the line, and the one-line fix. Do not fix
it yourself unless asked — surfacing it is the job.
