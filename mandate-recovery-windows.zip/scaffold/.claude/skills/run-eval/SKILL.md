---
name: run-eval
description: Run the full frozen evaluation across all stress regimes and both compliance profiles, and regenerate the three-bar report.
---

# Run evaluation

Delegate the run itself to the `eval-runner` subagent so the batch logs stay
out of this session's context. Then interpret the summary here.

1. Invoke `eval-runner`.
2. Write results to `reports/results.json`.
3. Regenerate `reports/three_bar.png` — money recovered, attempts spent,
   mandates preserved; ours vs the fixed T+1/T+2/T+3 ladder.
4. Regenerate `reports/calibration.png`.
5. Update the results table in README.md.

Interpretation rules — these matter more than the numbers:

- **A regime where we lose is a finding, not a failure.** Report it in the
  README with a sentence on why. An honest loss outscores a suppressed one,
  and a policy that wins every regime is evidence the regimes were tuned.
- Report BOTH error costs: missed recovery, and false off-ramp. A single
  accuracy number hides the asymmetry that matters.
- If a number moved by more than 3 points since the last run, find out why
  before writing it down. Unexplained improvement is usually leakage.
- Never adjust `eval/frozen/` to improve a number. The guard will block it;
  do not work around the guard.
