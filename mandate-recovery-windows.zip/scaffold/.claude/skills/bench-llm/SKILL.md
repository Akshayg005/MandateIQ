---
name: bench-llm
description: Run the LLM-as-classifier baseline against the statistical model and regenerate the decision table in DECISIONS.md.
---

# Benchmark: LLM vs statistical core

This benchmark is a scored deliverable. The rubric line is "AI judgment —
the right tool in the right place, and where you chose not to use one." An
assertion scores nothing. A measured comparison scores.

Run `.\run.ps1 bench` and report four
columns for each approach:

| | AUC | p95 latency | cost / 1k decisions | run-to-run variance |
|---|---|---|---|---|
| competing-risks model | | | | |
| Claude Haiku as classifier | | | | |
| Claude Sonnet as classifier | | | | |

**The variance column is the argument.** Run the identical input five times
and report how often the LLM returns a different decision. In a payments
path, same input producing a different retry time is disqualifying
regardless of accuracy — because it means the decision cannot be reproduced
in a dispute.

Write the table into `DECISIONS.md` under "Where we chose not to use a
model", with one sentence naming the column that decided it.

If the LLM wins on AUC, say so. Then explain why it still does not ship, or
change the architecture. Do not bury a result that went the other way.
