---
name: orient
description: Start-of-session ritual. Read the state files in order, answer the drift check, and restate today's goal before any work begins. Use as the first action in every new session.
---

# Orient

A new session starts blind. Reconstructing the goal from whatever source
files you happen to open is how a mandate-recovery engine becomes a generic
dunning tool by day eight. Read the spec, not the code.

## Step 1 — read, in this order

1. `STATE.md` — where the project actually is right now
2. `CLAUDE.md` — invariants and regulatory constants
3. `PLAN.md`, today's day only
4. `PLAN_DETAIL.md`, today's day only
5. `reports/gates.md` — which gates are open

Read nothing else yet. Do not open source files during orientation; that is
what makes a session start reconstructing intent instead of loading it.

## Step 2 — answer the drift check out loud

Answer all six DRIFT CHECK questions from `STATE.md` in your reply. Not
"I've read them" — actually answer them. If any answer is uncertain, say so
and re-read `CLAUDE.md` before continuing.

## Step 3 — report back, in this exact shape

```
ORIENTED — day <N>

Drift check:
  1. three states + actions: ...
  2. headline metric:        ...
  3. forbidden in core:      ...
  4. attempt budget:         ...
  5. never does:             ...
  6. frozen at:              ...

Where we are:      <from STATE.md, one line>
Next action:       <from STATE.md, one line>
Today's gate:      <from PLAN.md, restated>
Least confident:   <what the last session flagged>

Plan for today: <awaiting approval — do not write code yet>
```

## Step 4 — stop

Do not write code. Wait for the human to approve the day's plan. If
`STATE.md` says the last checkpoint is missing or stale, say so plainly —
a stale STATE.md means the previous session ended badly and something is
probably half-finished somewhere you have not been told about.
