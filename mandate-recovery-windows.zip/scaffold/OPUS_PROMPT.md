# Master prompt for Claude Code (Opus, plan mode)

**Version 2.** Changes from v1, all of which were real gaps:

1. Tells Opus to read the existing scaffold first, instead of planning from
   scratch and duplicating what is already there
2. States that the scaffold exists, so Day 1 morning is largely already done
3. Says where to write the plan output — a file, not a chat reply that dies
   on `/clear`
4. Lists the subagents available to it, so it actually uses them
5. Makes the standing rules (ask before cutting, log incidents live, never
   edit frozen) persistent instructions rather than one-time asks

---

## How to use it

```powershell
cd mandate-recovery
claude --model opus
```

Press `shift+tab` **twice** to enter plan mode. Confirm you see the plan-mode
indicator before pasting. Then paste everything between the fences.

---

```
You are the lead engineer on a 12-day build. Produce an implementation plan
before writing any code.

## 0. READ THESE FIRST -- THE SCAFFOLD ALREADY EXISTS

Before you plan anything, read, in this order:

  1. STATE.md                  -- where the project is RIGHT NOW + drift check
  2. CLAUDE.md                 -- invariants and regulatory constants
  3. PLAN.md                   -- the 12-day schedule and gate conditions
  4. src/core/CLAUDE.md, src/model/CLAUDE.md, src/policy/CLAUDE.md
  5. .claude/settings.json     -- the four hooks that are already live
  6. scripts/ -- guard_invariants.py, guard_frozen.py, hookio.py,
                 checkpoint.py, show_state.py
  7. .claude/agents/           -- eight subagents already defined
  8. .claude/skills/           -- seven skills already defined
  9. run.ps1 (the task runner -- this is a WINDOWS project, PowerShell
     not bash, no Makefile), reports/gates.md

Do NOT re-derive or re-propose anything already in those files. Your job is
to plan the code that does not exist yet, on top of a scaffold that does.
If you think something in the scaffold is wrong, say so explicitly rather
than quietly planning around it.

Already exists and is tested: the hooks, both guard scripts, all subagents,
all skills, the Makefile, the document templates. Does NOT exist yet: every
module under src/, everything under eval/, the bench script, the dashboard,
the landing page.

## 1. THE PRODUCT

A decision engine for failed recurring debits (subscriptions / UPI AutoPay
mandates) in India, built on Razorpay test-mode APIs.

When a recurring debit fails, every system on the market asks one question:
"will a retry succeed?" It then retries on a fixed schedule and halts after
three failures. Razorpay's documented behaviour is T+1, T+2, T+3, then halt.

That single rule conflates two completely different customers:
  - someone who was short Rs 300 three months running -- you just killed a
    paying customer who wanted to stay
  - someone who wants out and is passively letting the debit fail -- you
    just spent four attempts and three notifications harassing them

We ask a different question: WHICH OF THREE THINGS went wrong?
  1. CANT_PAY_NOW  -- transient liquidity. Time the attempt to their rhythm.
  2. CANT_PAY_EVER -- instrument dead (expired card, closed account,
                      revoked mandate). Stop; request re-authorisation.
  3. WONT_PAY      -- wants out. OFFER a clean exit: pause, then downgrade,
                      then cancel. Never execute a cancellation.

The system will sometimes deliberately recover less money this cycle to
protect lifetime value. That is the thesis, not a bug.

## 2. WHY NOW (regulatory grounding -- hard constraints)

RBI "Digital Payments - E-mandate Framework, 2026" (RBI/DPSS/2026-27/396,
21 April 2026) -- four months old, India-only:

  - 6(a): issuer must send a pre-transaction notification >=24h before every
    debit. CONSEQUENCE: attempts must be COMMITTED at least 24 hours ahead.
    Reactive retry is structurally impossible. We forecast; we do not react.
    This is why Stripe's approach -- reacting to dynamic signals in the last
    N hours -- does not transfer to India.
  - 6(c): the notification carries an AFA-validated opt-out for that
    transaction OR the whole mandate. Every attempt therefore risks losing
    the customer permanently. OPTED_OUT is a DISTINCT OUTCOME, not a decline.
  - 8(a)/(b): AFA-free up to Rs 15,000; Rs 1,00,000 for insurance, mutual
    funds, credit card bills. Above the cliff, silent retry is pointless --
    route to a customer re-authentication path.
  - 4(c): never attempt above the customer's mandate ceiling.
  - 10(c): acquirers are responsible for merchant compliance -- which is why
    a payment aggregator, not just a merchant, would want this. It drives a
    second dashboard persona.

NPCI limit: 1 original attempt + 3 retries. FOUR ATTEMPTS TOTAL, ever.
This is a scarce-budget allocation problem, not a scheduling problem.

IMPORTANT AMBIGUITY: the circular never uses the word "retry". Whether a
reattempt needs its own fresh 24h notification is genuinely unresolved. Do
NOT hard-code one interpretation. Ship two compliance profiles (strict /
permissive) and evaluate under both. Engineering for regulatory uncertainty
instead of assuming it away is a deliberate design goal, and one of the
things this project is being judged on.

CCPA Guidelines for Prevention and Regulation of Dark Patterns, 2023 list
"subscription trap" among 13 prohibited practices, with active enforcement
in 2026. Grinding an exit-intent customer is a legal exposure. Our off-ramp
is a compliance artifact, not just a kindness.

## 3. THE MODEL (settled -- implement it, do not redesign it)

Discrete-time COMPETING RISKS survival analysis.

  - Reshape to person-period format: one row per (mandate, attempt_slot).
  - Outcome per row: {RECOVERED, DEAD, OPTED_OUT, STILL_PENDING}.
  - Fit multinomial logistic regression over that frame. This IS a discrete
    cause-specific hazard model.
  - Derive cumulative incidence per cause per slot.
  - Calibrate with isotonic regression on a disjoint split; ship a
    reliability diagram.

Why competing risks and not a classifier: most mandates exhaust the
4-attempt budget without resolving. A classifier trained on "did it recover"
silently drops those censored cases and biases everything toward
fast-resolving mandates. Survival analysis handles right-censoring natively.

Respect this distinction: cause-specific hazards explain mechanism (for the
merchant narrative); subdistribution hazards predict an individual's risk
(for the allocator). Do not mix them up.

Action selection: EXACT backward induction over the 4 slots. The state space
is small enough to solve optimally -- do not use RL, do not use heuristic
search.

Objective:
  maximize  E[recovered] - P(opt_out)*mandate_LTV - attempt_cost
  s.t.      every attempt committed >=24h in advance
            amount <= mandate ceiling
            amount <= AFA-free limit, or routed to re-auth path
            attempts <= 4
            stopping rules honoured

DO NOT use DeepHit, transformers, or deep survival models. Insufficient
data, and it destroys the architectural argument.

## 4. WHERE AI LIVES -- AND WHERE IT DELIBERATELY DOES NOT

The decision core is deterministic + statistical. NO LLM TOUCHES A MONEY
DECISION. Enforced by scripts/guard_invariants.py as a PostToolUse hook on
every edit. If your plan requires an LLM call inside src/model/ or
src/policy/, the plan is wrong -- restructure it.

LLMs handle only unstructured language:
  - Haiku: normalising decline strings that differ across issuers;
    extracting cancellation intent from support text (including Hinglish)
  - Sonnet: merchant-facing root-cause narrative, once per batch,
    never per transaction

All structured LLM output goes through required tool-use so malformed JSON
is structurally impossible rather than caught downstream.

We will benchmark an LLM-as-classifier baseline against the statistical
model and publish AUC, p95 latency, cost per 1k decisions, and RUN-TO-RUN
VARIANCE on identical input. The LLM will lose. The variance column is the
argument: same input producing a different retry time means the decision
cannot be reproduced in a dispute. Ship the benchmark even though it goes
against the LLM. If it unexpectedly goes the other way, say so.

## 5. SAFETY DESIGN

Exit intent is WEAKLY IDENTIFIED from payment data alone. A false positive
cancels a paying customer -- the exact harm we exist to prevent. Therefore:
  - Use SPLIT CONFORMAL PREDICTION on the intent classifier. Only offer an
    off-ramp when the conformal set is the singleton {WONT_PAY} at 95%
    coverage. Everything else stays in the retry lane.
  - The system OFFERS; the customer decides. It never cancels.
  - Report BOTH error costs: missed recovery, and false off-ramp.

## 6. SUBAGENTS AVAILABLE TO YOU -- USE THEM

  stats-reviewer      (opus, read-only)   leakage, censoring, split integrity
  payments-domain     (opus, read-only)   skeptical staff engineer, argues back
  money-auditor       (sonnet, read-only) amounts, idempotency, ledger
  compliance-auditor  (sonnet, read-only) RBI clauses and NPCI limits
  chaos-engineer      (sonnet)            unhandled failure paths + tests
  test-writer         (sonnet)            failing tests before implementation
  eval-runner         (haiku)             runs batches, returns summary only
  frontend-dev        (sonnet)            dashboard and landing page

Delegate anything log-heavy to eval-runner so batch output never enters the
main context. Delegate any review to a read-only agent so it cannot silently
"fix" what it finds.

Skills: /orient /checkpoint /verify-invariants /log-incident /run-eval
        /new-failure-class /bench-llm

## 7. STANDING RULES (apply for all 12 days, not just now)

  - NEVER edit anything under eval/frozen/. The PreToolUse hook will deny
    it. Do not work around the hook.
  - NEVER narrow scope on your own initiative. If you think something should
    be cut or simplified, ASK ME FIRST and wait for an answer.
  - When something breaks, use /log-incident BEFORE fixing it. Write the
    symptom as observed, before the cause is known. Build incidents are a
    scored deliverable; reconstructed ones read as fake.
  - Plan mode before any non-trivial task. I approve the plan, then you code.
  - If a gate in reports/gates.md is not met, say so rather than ticking it.
    An honest open gate is worth more than a false green.
  - START every session with /orient. END every session with /checkpoint.
    You have no memory across sessions; STATE.md is the only thing that
    carries. A session that ends without a checkpoint costs the next one
    twenty minutes and hides whatever was left half-finished.
  - Never reconstruct the project's goal from source files. Read STATE.md
    and CLAUDE.md. Inferring intent from code is how this becomes a generic
    dunning tool by day eight.

## 8. EVALUATION (pre-registered Day 1, frozen before any policy code)

Baseline: the fixed T+1/T+2/T+3 ladder, then halt.
Batch: 200 synthetic mandates, calibrated to published Indian
recurring-payment statistics.

Report THREE bars, not one:
  (a) money recovered   (b) attempts spent   (c) MANDATES PRESERVED

Run under BOTH compliance profiles. Run five stress regimes NOT used for
tuning: issuer outage, delayed salary, mandate-stacking spike, festival
season, competitor retry storm.

REPORT WHERE WE LOSE. An honest loss scores higher than a suppressed one,
and a policy that wins every regime is evidence the regimes were tuned.

Split at the MANDATE level, never the row level. Person-period data makes
row-level splitting look fine while putting the same mandate on both sides.

## 9. STACK

Python 3.11 - FastAPI - Postgres - statsmodels (MNLogit) - lifelines -
scikit-learn - MAPIE - anthropic SDK - razorpay SDK - APScheduler.
React + Vite for the dashboard. React Three Fiber for the landing page.
The Razorpay MCP server is wired into this session with test keys -- use it
to create real test-mode orders, subscriptions and payment links instead of
hand-writing fixtures.

## 10. FULL SCOPE -- 12 DAYS, NOTHING CUT

Beyond the core engine, this build includes all of:
  - Split conformal prediction gating the off-ramp, with empirical coverage
    verification on held-out data
  - Isotonic calibration + a reliability diagram in reports/
  - The LLM-as-classifier benchmark above, variance column included
  - Constrained decoding via required tool-use for every structured output
  - A golden set (50 decline strings, 30 intent cases) wired into the Stop
    hook so a prompt edit that regresses accuracy fails the build
  - Shadow mode: decide without executing, log the delta vs the fixed ladder
  - BOTH compliance profiles evaluated end to end
  - All five stress regimes, none used for tuning
  - Two dashboard personas: merchant view and acquirer view (clause 10(c))
  - A chaos harness: 50 induced kills proving zero double-charges
  - A 3D scroll-narrative landing page in a separate worktree that animates
    the three-way cause split and ends on the mandates-preserved comparison

Plan all of it. If you believe any item is not achievable in the day it is
allocated in PLAN.md, SAY SO NOW and propose a different allocation. Do not
silently drop it.

## 11. WHAT I WANT FROM YOU NOW

Write your plan to a NEW file, PLAN_DETAIL.md, so it survives /clear.
Do not put it only in the chat.

PLAN_DETAIL.md must contain:

  1. A file-by-file implementation plan mapped to PLAN.md's 12 days. For
     each file: its responsibility, its public interface, what it must NOT
     do, and which day it lands.
  2. The exact person-period schema: every column, its dtype, and precisely
     how right-censoring is encoded. Show one worked example row for a
     mandate that recovered on slot 3, and one for a mandate that exhausted
     all four slots without resolving.
  3. The ledger schema, with the idempotency key derivation written out as a
     formula, and the exact write ordering around a Razorpay call.
  4. The backward-induction algorithm in pseudocode, including how the belief
     state is represented and updated after each observed outcome.
  5. The three highest-risk parts of this build and how you would de-risk
     each. Be concrete -- a test, a spike, an earlier gate.
  6. A dependency graph: what must exist before what. I want to know which
     day-slips cascade and which are contained.

Then, in the chat (not the file):

  7. Anything in this spec you think is WRONG. Argue with me before we build.
     I would rather lose an hour now than three days on day nine. If you
     think the spec is sound, name the assumption you are least comfortable
     with.

Do not write any code yet. Plan first.
```

---

## The four recurring prompts

### After the plan comes back

```
Before we start building: run the payments-domain subagent against your own
PLAN_DETAIL.md. Report what it says without defending yourself. Then tell me
which of its objections you think are correct, and which you would push back
on and why.
```

### Start of each build day

```
/orient
```

That's the whole prompt. The skill reads STATE.md, CLAUDE.md, today's day in
PLAN.md and PLAN_DETAIL.md, and reports/gates.md, then answers the six
drift-check questions and restates today's gate.

**Check its six answers before approving anything.** If the headline metric
comes back as "recovery rate" instead of the three bars including mandates
preserved, it has drifted — stop and make it re-read CLAUDE.md.

Then:

```
Now give me the file-by-file plan for today only, and name the one thing
most likely to go wrong. Do not write code until I approve.
```

### When something breaks

```
Use /log-incident first, before fixing anything. Write the symptom as you
observed it, before you know the cause. Then diagnose, then propose the fix,
then tell me what guard would prevent the whole class of bug.
```

### End of each build day

```
/checkpoint
```

The skill runs /verify-invariants, regenerates STATE.md via
`.\run.ps1 checkpoint -Day <n>`, appends to SESSIONS.md, and prompts for the four
hand-written handoff fields.

Then read the handoff yourself. If "where I stopped, exactly" says something
like "continued work on the allocator", send it back — that is a topic, not
a position, and tomorrow's cold session cannot resume from it.
