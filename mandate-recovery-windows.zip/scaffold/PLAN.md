# PLAN — 12 days, nothing cut

**Target:** Razorpay AI Buildathon, Track 03 (AI Revenue Recovery).
**Deliverable:** public repo + 5-minute pitch video + architecture.

Two of Track 03's seven listed example directions are exactly this project:
*mandate retry sequencer* and *failed-subscription recovery*.

---

## The one-line pitch

> Every retry engine asks "will this payment succeed?"
> Ours asks "which of three things went wrong?" — and sometimes concludes
> the right action is to let the customer go.

---

## The scored rubric, and what satisfies each line

| Criterion | What satisfies it here |
|---|---|
| **Problem taste** | Involuntary churn is 20–40% of total churn. Razorpay's documented behaviour is a fixed T+1/T+2/T+3 ladder, then halt — so the baseline is the incumbent, not a strawman |
| **Build quality** | Integer paise, append-only ledger, idempotency proven under 50 induced kills, invariants enforced by git hooks rather than prose |
| **AI judgment** | Deterministic decision core with a measured LLM-vs-statistical benchmark showing why. The run-to-run variance column is the argument |
| **Failure recovery** | POSTMORTEM.md written live during the build, plus a chaos harness and a graceful-degradation demo in the video |
| **The track's bar** | Measured money recovered across a batch, compliant escalation via the AFA cliff, explicit stopping rules, append-only audit trail |

---

> **Windows:** this repo is Windows-native. Wherever a command below reads
> `make <task>`, run `.\run.ps1 <task>`. Full mapping in
> `SETUP_GUIDE_WINDOWS.md`. Setup is `.\setup.ps1`, not `./setup.sh`.

## Day 0 — Environment (2 hours, do it tonight)

```powershell
mkdir mandate-recovery; cd mandate-recovery; git init
# unzip the scaffold here and flatten it, then:
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\setup.ps1
```

`setup.ps1` handles the venv, dependencies, Postgres in Docker, both Vite
workspaces, `.env`, and a self-test that the guards actually fire.

The webhook tunnel is **not needed until Day 2** — skip it now. When you get
there, use Cloudflare (no account required, unlike ngrok):

```powershell
& "$HOME\cloudflared.exe" tunnel --url http://localhost:8000
```

Razorpay MCP into Claude Code — **test keys only**:

```powershell
$kid  = "rzp_test_xxxxx"
$sec  = "xxxxx"
$auth = "Basic " + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("${kid}:${sec}"))
$cfg  = @{ command = "npx"
           args = @("mcp-remote","https://mcp.razorpay.com/mcp","--header","Authorization:$auth")
         } | ConvertTo-Json -Compress
claude mcp add-json razorpay $cfg
claude mcp list

git worktree add ..\mr-site site
```

Then verify everything before building:

```powershell
.\run.ps1 verify
```

---

## Day 1 — Foundation and the freeze

**The most important day.** If the freeze does not happen today, every
number you produce for the next eleven days is unfalsifiable.

**Morning.** Drop in this scaffold: both `CLAUDE.md` levels, `.claude/settings.json`,
the five scripts, eight subagents, seven skills, run.ps1.

Then **test the guards by breaking them deliberately**:

```bash
echo "amount: float = 1.5" >> src/model/_scratch.py
python scripts/guard_invariants.py src/model/_scratch.py   # must exit 2
rm src/model/_scratch.py
```

**Afternoon.** Ledger schema. Repo skeleton with stub modules so imports resolve.

**Evening — the freeze.** Write `eval/frozen/sim_config.yaml`: 200 mandates,
three latent states with transition parameters, four attempt slots, amount
distribution spanning the ₹15,000 AFA cliff, contact-response parameters.
Write `eval/frozen/protocol.md`: exactly what you will measure, on which
split, what counts as a win, and what counts as a loss. Implement
`eval/baseline_ladder.py` — the fixed T+1/T+2/T+3 halt behaviour.

```bash
git add -A
git commit -m "FREEZE: evaluation protocol, pre-registered before any policy code"
git rev-parse HEAD | tee reports/FREEZE_HASH
```

Then initialise the session-state system:

```bash
.\run.ps1 checkpoint -Day 1
```

Fill the handoff section of `STATE.md` by hand before you stop.

**Gate:** baseline produces a number · both guards fire on violation · hash
recorded · `STATE.md` initialised with a real handoff.

---

## Day 2 — Ingest, ledger, taxonomy

Webhook receiver with **timing-safe** HMAC verification, event dedupe by
`event_id`, timestamp replay window. Append-only ledger with the decision
record shape. `src/classify/decline_taxonomy.py` and `cause_map.py` — the
deterministic map from issuer decline codes to the three causes.

Capture a real `payment.failed` from Razorpay test mode end to end.

Run `payments-domain` on the taxonomy. It will tell you your decline-code
coverage is optimistic. It will be right.

**Gate:** a real test-mode webhook lands in the ledger with a classified cause.

---

## Day 3 — The competing-risks model  *(Opus)*

`person_period.py` — reshape to one row per `(mandate, attempt_slot)`, with
outcome ∈ `{RECOVERED, DEAD, OPTED_OUT, STILL_PENDING}` and censoring
encoded explicitly, not as a missing value.

`competing_risks.py` — multinomial logit over that frame. This *is* a
discrete-time cause-specific hazard model.

`cif.py` — cumulative incidence per cause per slot.

Then run `stats-reviewer` on the whole directory and fix everything it finds
about censoring and leakage **before moving on**. A leak found on Day 3 costs
an hour; the same leak found on Day 11 costs the submission.

**Gate:** model beats the ladder on nominal-regime recovery · split is at the
mandate level, not the row level · no feature encodes a future slot.

---

## Day 4 — Calibration and conformal  *(Opus)*

`calibration.py` — isotonic regression on hazard outputs, fit on a split
disjoint from the one you report on. Reliability diagram to
`reports/calibration.png`.

`conformal.py` — split conformal prediction on the intent classifier. An
off-ramp is offered **only** when the conformal prediction set is the
singleton `{WONT_PAY}` at 95% coverage. Everything else stays in the retry lane.

Roughly 40 lines with MAPIE, or written by hand. It buys you a sentence
almost nobody at this hackathon can write: *the off-ramp lane's error rate is
bounded at 5% under exchangeability — as a property, not a hope.*

**Gate:** reliability diagram roughly diagonal · empirical conformal coverage
matches its nominal level on held-out data.

---

## Day 5 — Allocator and constraints  *(Opus)*

`allocator.py` — **exact backward induction** over four slots.
State = (belief over three causes, slots remaining, cycle position).

```
maximize  E[recovered] − P(opt_out)·mandate_LTV − attempt_cost
s.t.      every attempt committed ≥24h in advance      (6a)
          amount ≤ mandate ceiling                      (4c)
          amount ≤ AFA-free limit, or → re-auth path    (8a/8b)
          attempts ≤ 4                                  (NPCI)
          stopping rules honoured
```

The state space is small enough to solve optimally. Do not introduce RL, and
say in the README that you solved it exactly.

`constraints.py` — all six clauses, each with its citation in a docstring.
The 24-hour commitment lag is a **hard interface property**: the allocator
emits a committed schedule, and information arriving inside the window
cannot pull an attempt earlier.

`profiles.py` — `strict` and `permissive`. `stopping_rules.py` — attempt cap,
quiet hours, contact frequency, opt-out honoured permanently, revoked
mandate never retried.

**Gate:** zero constraint violations across the whole eval · both profiles
produce numbers · `compliance-auditor` returns all-VERIFIED.

---

## Day 6 — Executor, idempotency, chaos

Idempotency key = `hash(mandate_id, cycle, attempt_index, action)` — stable
across restarts, containing nothing from the current process. Ledger write
**before** the money action, always. Lease-based claiming with crash-safe
resumption. Razorpay test-mode integration including subscription
pause/resume.

Then chaos:

```bash
.\run.ps1 chaos -Kills 50
```

`kill -9` the executor mid-attempt, fifty times, at random points.

**Log every break in POSTMORTEM.md as it happens**, using `/log-incident`.
Reconstructed incidents read as fake. These are a scored deliverable.

**Gate:** 50 induced kills · zero double-charges · zero lost jobs · ledger complete.

---

## Day 7 — Off-ramp and the LLM edge

`offramp.py` — pause → downgrade → cancel, **offer only**, wired to
Razorpay's subscription pause/resume. Razorpay's own research says roughly
10% of customers who cancel auto-renewal would have preferred to pause;
that makes the off-ramp deferred revenue, not lost revenue. Cite it.

`src/llm/` — Haiku normalising decline strings across issuer formats; Haiku
extracting cancellation intent from support text including Hinglish; Sonnet
writing the merchant root-cause narrative once per batch. All structured
output through required tool-use so malformed JSON is structurally impossible.

Golden set: 50 labelled decline strings, 30 labelled intent cases, wired
into the `Stop` hook so a prompt edit that regresses accuracy fails the build.

**Gate:** off-ramp fires only on singleton conformal sets · golden set passes
· no LLM import anywhere under `src/model/` or `src/policy/`.

---

## Day 8 — The benchmark and shadow mode

`bench/llm_vs_stats.py` — LLM-as-classifier against the competing-risks
model on the same held-out split. Report AUC, p95 latency, cost per 1k
decisions, **and run-to-run variance on identical input**.

That last column is the one that disqualifies the LLM from a money path:
same input, different retry time, means the decision cannot be reproduced in
a dispute. **This day is your AI-judgment evidence — do not rush it.**

`shadow.py` — decide without executing, log the delta against what the
ladder would have done. This is how payment systems actually roll out, it is
a day's work, and it is the direct answer to "what about real data."

**Gate:** benchmark table written into DECISIONS.md · shadow mode produces a
delta log over the full batch.

---

## Day 9 — Stress regimes and the report

Five regimes you did **not** tune on: issuer outage, delayed salary,
mandate-stacking spike, festival season, competitor retry storm. All five ×
both compliance profiles.

The three-bar report: **money recovered · attempts spent · mandates
preserved** — ours vs the fixed ladder. Plus both error costs quantified:
missed recovery, and false off-ramp.

**Record where you lose.** A policy that wins every regime is evidence the
regimes were tuned. An honest loss with an explanation outscores a
suppressed one.

**Gate:** every number reproducible by one command · at least one regime
where you lose, explained.

---

## Day 10 — Reviewer dashboard

Dense tables, monospace numerals, fast, zero animation. It should look like
a finance tool, because "would you trust it" is the criterion.

Per-mandate drill-down: belief distribution over the three causes, chosen
slot and why, which constraint bound the decision, the conformal set, the
full ledger trail.

Two personas: **merchant view** and **acquirer view**. The second exists
because RBI clause 10(c) makes acquirers responsible for merchant
compliance — that is clause 10(c) rendered as product, and it is your answer
to "why would Razorpay ship this rather than a merchant."

---

## Day 11 — The 3D landing page (parallel worktree)

```powershell
cd ..\mr-site; claude    # second session, separate context
```

Animate the thesis, not decoration:

1. 200 instanced cubes drift toward a debit date. Quiet.
2. Most turn green and pass through. ~40 stop dead, go grey.
3. The fixed ladder runs — the grey mass is hammered three times and a third
   crumbles to dust. Counter: *mandates lost: 14*.
4. Rewind. The grey mass splits into three coloured streams — teal recovers,
   blue re-authorises, amber peels gently away and **parks intact, still glowing**.
5. Two counters: *mandates preserved — ladder: 26 · ours: 38*.

Anyone who scrolls that understands the product without reading a word.

Stack: R3F + drei, GSAP ScrollTrigger on normalized progress, Lenis,
`<Instances>` for the cubes (one draw call, never 200 meshes), Bloom only.
Hard rules: 60fps on a mid laptop or reduce the count; `prefers-reduced-motion`
gets a static three-frame storyboard; canvas failure falls back to plain HTML;
lazy-load the three.js bundle.

---

## Day 12 — Ship

**README.md** — problem, architecture diagram, the three-bar table, the
conformal bound, the freeze hash, and an explicit **"What this can't do"**
section with at least four honest items.

**DECISIONS.md** — the model-vs-no-model table including the benchmark you
lost on purpose.

**POSTMORTEM.md** — cleaned up from the running notes. Not invented.

**Architecture diagram** — Excalidraw, with the deterministic core and the
LLM edge in visibly different colours. That colour split is the diagram's
whole argument.

**The video.** Script it before recording. Three takes maximum.

| Time | Beat |
|---|---|
| 0:00–0:45 | The problem: a fixed ladder kills paying customers and harasses leavers |
| 0:45–2:15 | Live batch run — 200 mandates, the three-way split happening |
| 2:15–2:45 | The three bars, especially *mandates preserved* |
| 2:45–3:30 | Induced failure handled gracefully — kill the worker, show no double-charge |
| 3:30–4:00 | What it can't do. Name the limitation of the synthetic evaluation |
| 4:00–4:20 | Close on the one line |

---

## Session discipline and the context problem

Claude Code starts every session blind. Over twelve days that is roughly
twenty-five cold starts, and each one is a chance to drift off the thesis.
The window's size is not the issue — the reset is. State therefore lives in
files.

### The session protocol — every single session, no exceptions

```
OPEN    /orient        read STATE.md, answer the six drift-check questions,
                       restate today's gate. No code until the plan is approved.
WORK    plan mode first (shift+tab twice). Break something -> /log-incident
                       BEFORE fixing it.
CLOSE   /checkpoint    .\run.ps1 checkpoint -Day <n>, tick gates, write
                       the handoff by hand, commit.
```

`STATE.md` is the handoff. It carries the drift check, the auto-generated
position block, and four hand-written fields: where you stopped exactly, the
single next action, what is half-finished, and what you are least confident
about. Those four are the ones a script cannot infer and the next session
cannot live without.

The `SessionStart` hook prints a directive rather than a summary — a summary
invites the model to work from the summary instead of the source, and that
is precisely how drift starts.

### Keeping the window usable within a session

| Lever | Why it matters |
|---|---|
| Delegate batch runs to `eval-runner` (Haiku) | Largest single lever. Batch logs never enter the main context |
| Read-only review agents burn their own context | `stats-reviewer`, `money-auditor`, `payments-domain`, `compliance-auditor` |
| Never paste a CSV or full test log | Write a script that prints a summary instead |
| Constraints go in a `CLAUDE.md`, not a prompt | If you are re-explaining it, it belongs in a file |
| `/clear` between days | Never `/compact` mid-task — compaction silently drops invariants |

### Model routing

```powershell
claude --model opus      # Days 3, 4, 5 — modelling, conformal, allocator
claude --model sonnet    # everything else
```

- **Plan mode first** (`shift+tab` twice) on every non-trivial task. Reading
  a plan costs 30 seconds; reading 600 lines of wrong code costs an hour.
- Never `--dangerously-skip-permissions` on the money path.
- Run `compliance-auditor` at the end of Days 5, 6, 7 — fresh context each
  time, so it will not rationalise yesterday's shortcuts.
- Run `payments-domain` on Days 3, 5, 9. Let it argue with you.
- Run `money-auditor` on every diff touching `src/execute/` or `src/ledger/`.

---

## If you fall behind

You will, around Day 6. Before cutting anything, decide deliberately —
**do not let scope drift silently.** In rough order of what costs least:

dashboard polish → the Sonnet narrator (keep the Haiku normaliser) → two of
the five stress regimes (keep issuer outage and mandate stacking) → the 3D
page (ship a static poster instead).

**Never cut:** the frozen eval, the idempotency proof, the conformal gate,
the three-bar report, the LLM benchmark, or POSTMORTEM.md. Those six *are*
the submission.

---

## Two rules about "at any cost"

**Never fabricate a number.** A panel that catches one invented metric
discards everything else you built. This design produces enough real numbers
that you will not need to.

**Sleep on Days 4, 5 and 9.** Conformal prediction, the allocator, and the
stress analysis are the parts that need a working brain — and they are the
parts that win.
