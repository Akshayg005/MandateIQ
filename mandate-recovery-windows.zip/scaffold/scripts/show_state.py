#!/usr/bin/env python3
"""SessionStart hook: force orientation before any work begins.

Runs automatically at the start of every Claude Code session. Its output is
prepended to the session, so this is the first thing the model sees.

The design point: do not summarise the project here. Summaries invite the
model to work from the summary instead of the source, and a summary of a
summary is exactly how a project drifts. Instead, this prints a short
directive and the two or three facts that make skipping it costly.
"""
from __future__ import annotations

import pathlib
import re
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent.parent


def read(rel: str, default: str = "") -> str:
    p = ROOT / rel
    return p.read_text().strip() if p.exists() else default


def sh(*args: str) -> str:
    try:
        return subprocess.run(
            args, cwd=ROOT, capture_output=True, text=True, timeout=5
        ).stdout.strip()
    except Exception:
        return ""


def main() -> None:
    freeze = read("reports/FREEZE_HASH")
    gates = read("reports/gates.md")
    todo = [l.strip()[6:] for l in gates.splitlines() if l.strip().startswith("- [ ]")]
    done = len([l for l in gates.splitlines() if l.strip().startswith("- [x]")])
    total = done + len(todo)

    state = read("STATE.md")
    m = re.search(r"\*\*Last checkpoint:\*\*\s*(.+)", state)
    stamp = m.group(1).strip() if m else "NEVER — run `make checkpoint`"

    nxt = ""
    m = re.search(r"### The single next action\s*\n\s*\*\(.*?\)\*\s*\n+(.+)", state, re.S)
    if m:
        first = m.group(1).strip().splitlines()[0].strip()
        if first and first not in ("—", "-"):
            nxt = first

    dirty = sh("git", "status", "--porcelain")
    n_dirty = len(dirty.splitlines()) if dirty else 0

    out = [
        "════ MANDATE RECOVERY ENGINE ════",
        "",
        "STOP. Before doing anything else this session:",
        "  1. Read STATE.md  — where the project actually is",
        "  2. Answer the six DRIFT CHECK questions in it, out loud",
        "  3. Read PLAN.md for today's day, and restate today's gate",
        "",
        "  Do not infer the goal from the code you happen to read. A new",
        "  session that reconstructs intent from source drifts; that is the",
        "  failure mode this file exists to prevent.",
        "",
        f"last checkpoint : {stamp}",
        f"gates           : {done}/{total} passed"
        + (f"  ·  next: {todo[0]}" if todo else "  ·  all closed"),
        f"eval frozen     : {freeze[:12] if freeze else '** NOT FROZEN — Day 1 blocker **'}",
    ]
    if nxt:
        out.append(f"next action     : {nxt}")
    if n_dirty:
        out.append(f"working tree    : {n_dirty} uncommitted file(s)")

    out += [
        "",
        "Reminders: plan mode first (shift+tab twice). /clear between days,",
        "never /compact mid-task. Never narrow scope without asking first.",
        "End the session with /checkpoint  (Windows: .\\run.ps1 checkpoint -Day N).",
        "═════════════════════════════════",
    ]
    print("\n".join(out))


if __name__ == "__main__":
    main()
